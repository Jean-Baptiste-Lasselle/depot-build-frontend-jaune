'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API: 'window.location.protocol+"//"+window.location.host'
}
