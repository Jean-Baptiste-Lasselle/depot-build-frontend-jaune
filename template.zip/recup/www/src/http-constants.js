import axios from 'axios'

let baseURL

if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
  baseURL = 'http://127.0.0.1/'
} else {
  baseURL = 'http://api.jbl.test.io'
}

// pour simple test
baseURL = 'http://the_yellow_vote_back:5680/'

export const HTTP = axios.create (
{
    baseURL: baseURL
})
