<template>
  <div class="hello">
    <div v-if="!register && !merci">
      <h1><b>Préambule à la Charte Commune des Gilets Jaunes</b></h1>
      <blockquote><p><i><b>Face au traitement médiatique qui ne cesse de tenter de discréditer un mouvement populaire soutenu dans sa légitimité par une très large majorité de français, Nous, Gilets Jaunes de France, entendons proclamer nos valeurs et rappeler ce qui nous unit&nbsp;:</b></i></p></blockquote>
<ul>
<li>nous déplorons le dévoiement de nos institutions par des gouvernants qui ont abandonné la poursuite de l’intérêt général au profit de quelques intérêts particuliers privilégiés, pervertissant en toute impunité nos biens communs les plus précieux que sont la République et la Démocratie&nbsp;;</li>
<li>nous proclamons le caractère fondamental de nos libertés publiques, en particulier la liberté de manifester, et dénonçons la dérive autoritaire d’un gouvernement qui, faute d’adhésion majoritaire à son idéologie politique, s’applique à étouffer la contestation populaire par la répression policière et judiciaire.</li>
<li>nous affirmons que l’économie doit se soumettre à la décision du politique, libérée des lobbys et avec la participation des citoyens, pour instaurer une répartition des richesses équitable, opérer l’urgente et impérieuse transition écologique, et redonner du sens aux valeurs humaines essentielles&nbsp;: la dignité, le respect, le partage et la fraternité&nbsp;;</li>
<li>nous souhaitons vivre dans un monde plus juste avec tous les êtres humains, quelles que soient leurs histoires personnelles, leurs origines, leurs croyances et leurs différences&nbsp;;</li>
</ul>
<h2><strong>NOS REVENDICATIONS</strong></h2>
<ul>
<li>Sur le plan institutionnel&nbsp;: introduire la possibilité d’intervention directe du peuple dans la démocratie via le Référendum d’Initiative Citoyenne (RIC) en toutes matières.</li>
<li>Sur le fond&nbsp;: la politique doit servir les intérêts des 99% de la population et non plus seulement des 1% les plus riches&nbsp;(liste non exhaustive&nbsp;: baisse de la fiscalité pour la classe moyenne et les PME, augmentation des salaires, ré-indexation des retraites et des allocations familiales sur l’inflation, revalorisation du minimum vieillesse et de l’allocation adulte handicapé, dégel du point d’indice des fonctionnaires, suppression de la TVA sur les produits de première nécessité, lutte contre l’évasion et la fraude fiscale, défense de nos services publics essentiels, arrêt des privatisations du patrimoine public, etc.).</li>
</ul>
<h2><strong>NOS MOYENS D’ACTION</strong></h2>
<ul>
<li>nous entendons mener un rapport de force politique pacifique afin qu’aboutissent nos revendications ;</li>
<li>nous affirmons notre volonté de continuer à nous structurer de manière démocratique afin de poursuivre le processus constituant initié au sein du mouvement permettant à terme de rénover nos institutions ;</li>
<li>nous refusons catégoriquement de nous présenter aux élections européennes, que ce soit au sein d’une liste «&nbsp;Gilets Jaunes&nbsp;» ou au sein d’un parti ou mouvement politique existant.</li>
</ul>
  <br/>
  <b>  Nous affirmons solennellement que toute personne adoptant des positions contradictoires ou tenant des propos contraires aux principes énoncés ci-dessus est dénuée de toute légitimité pour s’exprimer au nom du mouvement des Gilets Jaunes.</b>

  <br/><br/><br/>
<div v-if="toVote">
  <button class="gris" v-on:click="vote(false)" :disabled="sending">Refusé</button>
  <button class="success voteOui" v-on:click="vote(true)" :disabled="sending">Lu et approuvé</button>
  <br/><br/><br/>
</div>
<div  v-if="!toVote">
  <b>Vous avez déjà voté! Merci.</b><br/>
    <p>
    Dans quelques jours, vous pourrez accéder à la <a href="https://lalignejaune.fr">nouvelle plateforme ici</a> ! Nous vous enverrons une notification à ce sujet.
    </p>

</div>

</div>

<div v-if="register" class="register">

  <h2>Pour prendre en compte votre vote, nous avons besoin de vérifier votre adresse email. Ceci prendra quelques secondes seulement.</h2>

  <table class="questionForm">
      <tr><td>
        Entrez votre adresse email:<br/>
        <input id="email" ref="email" type="email" v-model="email" placeholder="">
      </td></tr>
  </table>

  <button :disabled="sending || email.length<7 " v-on:click="doRegister" class="success">Envoyer mon vote</button>

</div>

 <div v-if="merci">

    <h2>C'est presque prêt!</h2>

    <p><b>Un email vous attend dans votre boîte de réception. Vérifiez le dossier spam si vous ne le trouvez pas.</b><br/><br/>

    <b>Ouvrez cet email, et cliquez sur le lien qu'il contient afin de valider votre vote.</b> </p>
    <br/>Merci :)
   </div>
<div class="alert" style="position: fixed; top: 0px; width: 300px;" v-if="result" v-bind:class="{ error: result.error }">
      <span class="closebtn" v-on:click="result=null;">&times;</span>
      {{result.text}}     </div>

</div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Hello',
  data () {
    return {
      toVote: true,
      voteChoix: true,
      register: false,
      merci: false,
      email: '',
      sending: false,
      result: null
    }
  },
  created () {
    var user = this.$cookies.get('user')
    if (user) this.toVote = false // this.$router.push('register')
  },
  methods: {
    vote (val) {
      this.voteChoix = val
      this.register = true
      // this.$nextTick(() => this.$refs.email.focus())
    },
    doRegister () {
      if (this.email.trim().length >= 7 && this.email.indexOf('@') >= 0) {
        this.sending = true
        axios.post(process.env.API + '/api/register', {email: this.email, vote: this.voteChoix})
          .then(res => {
            console.log(res)
            if (res.data.error) {
              this.result = res.data
              setTimeout(() => this.$router.go(), 8000)
            } else {
              this.register = false
              this.merci = true
            }
            // display thank you, verify email
          }, error => {
            console.log(error)
            // display message erreur
            this.result = { error: 20, text: error.message }
            this.sending = false
          })
      } else {
        this.result = { error: 21, text: 'l\'adresse email fournie est invalide' }
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: disc;
  padding: 0;
  text-align: left;
}
li {
  margin: 20px 40px;
}

.voteOui {
  margin-left:8px;
}

a {
  color: #42b983;
}

blockquote {
  font-size: 1.05em;
}

.register {
  max-width: 800px;
  margin:auto;

}
.hello {
  max-width: 800px;
  margin:auto;
}
</style>
