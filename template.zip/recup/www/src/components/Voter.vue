<template>
  <div>
    <div class="theend" v-if="approved">
      <h1> Votre vote a été pris en compte!</h1>
      <img class="approved" src="/static/approval.png">

<p>
Dans quelques jours, vous pourrez accéder à la nouvelle <b>Plateforme Collaborative des Gilets Jaunes</b> que nous sommes en train de préparer! Nous vous enverrons une notification à ce sujet.
    </p>
    <div v-if="!merci">

    <p>En attendant, vous pouvez nous donner quelques indications personnelles afin de pouvoir revenir vers vous avec toutes les informations locales GJs qui vous concernent.
  </p>

    <h3> A propos de moi</h3>

 <table class="questionForm">
      <tr><td>
        Mon prénom ou pseudonyme:<br/>
        <input id="nom" type="text" v-model="nom" placeholder="">
      </td></tr>
      <tr><td>
        Mon code postal:<br/>
        <input id="zip" maxlength="5" type="text" v-model="zip" placeholder="" >
      </td></tr>

  </table>

  <button :disabled="sending || nom.trim().length<3 || zip.trim().length != 5 " v-on:click="completer" class="success">Envoyer ces détails</button>
  </div>
  <div  v-if="merci" >
<br/><br/>
    <h1>Nous reviendrons vers vous très rapidement.</h1>
    </div>

  <h3>Partager ce site</h3>
   Et abonnez-vous pour recevoir plus d'infos<br/><br/>

      <table class="share">
      <tr>
        <td><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A//charte.lalignejaune.fr"> <img width=50 height=50 src="/static/fb.png"></a></td>
        <td><a target="_blank" href="https://twitter.com/JauneFR"> <img width=64 height=52 src="/static/tw.png"></a></td>
        <!--td><a target="_blank" href="#">  <img width=64 height=45 src="/static/yt.png"></a></td-->
      </tr>
      <tr>
        <td><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A//charte.lalignejaune.fr">  facebook </a></td>
        <td><a target="_blank" href="https://twitter.com/JauneFR">  twitter </a></td>
        <!--td><a target="_blank" href="#">  youtube </a></td-->
      </tr>

      </table>
          <br/>
          <router-link to="/">Retour à la charte</router-link>
          <br/><br/>

    </div>
    <div class="alert" style="position: fixed; top: 0px; width: 300px;" v-if="result" v-bind:class="{ error: result.error }">
      <span class="closebtn" v-on:click="result=null;">&times;</span>
      {{result.text}}     </div>
 </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Voter',
  data () {
    return {
      approved: false,
      result: null,
      sending: false,
      merci: false,
      nom: '',
      zip: ''
    }
  },
  created: function () {
    // console.log('created')
    // TODO check cookie

    axios
      .get(process.env.API + '/api/verif/' + this.$route.params.hash)
      .then(response => {
        console.log(response)
        if (response.data.error && response.data.error !== 7) {
          this.result = response.data
          setTimeout(() => this.$router.push('/'), 8000)
        } else {
          // TODO set cookie
          this.$cookies.set('user', {hash: this.$route.params.hash}, '10y', null, 'lalignejaune.fr', true)
          this.approved = true
        }
      }, (error) => {
        this.result = {error: 30, text: error.toString()}
        setTimeout(() => this.$router.push('/'), 8000)
      })
  },
  methods: {
    completer () {
      if (this.sending) return
      axios
        .post(process.env.API + '/api/completer/' + this.$route.params.hash, {
          nom: this.nom,
          zip: this.zip
        })
        .then(response => {
          this.sending = false
          if (response.data.error) {
            this.result = response.data
            setTimeout(() => (this.result = null), 8000)
          } else {
            this.result = { text: 'Merci pour ces détails ' + this.nom + '!' }
            this.merci = true
          }
        }, (error) => {
          this.sending = false
          this.result = {error: 30, text: error.toString()}
          setTimeout(() => (this.result = null), 8000)
        })
    }
  }
}
</script>

<style>
</style>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

blockquote {

}

.theend {
  max-width: 800px;
  margin:auto;
}

#nom {
  text-align: center;
}

#zip {
  width: 85px;
}

h1 {
  font-weight: bold;
  font-size:1.7em;
}
h2 {
  font-weight: normal;
  margin-bottom:40px;
}
ul {
  list-style-type: disc;
  padding: 0;
  text-align: left;

}
li {
  margin: 20px 40px;
}
a {
  color: #42b983;
}

.approved {
  margin: auto;
}

.share {
  margin: auto;
}

</style>
