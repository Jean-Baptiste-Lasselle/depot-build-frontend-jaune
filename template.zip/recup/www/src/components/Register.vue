<template>
  <div class="register">

    <div v-if="!merci">

     <h2>Créer un compte</h2>

    <table class="questionForm">
      <tr><td>
        Entrer votre adresse email:<br/>
        <input id="email" type="email" v-model="email" placeholder="" :autofocus="'autofocus'">
      </td></tr>
      <tr><td>
        Entrer un nouveau mot de passe.<br/>
        Il doit contenir au minimum 8 charactères:<br/>
        <input id="passwd1" type="password" v-model="passwd1" placeholder="">
      </td></tr>
      <tr><td>
        Entrer le même mot de passe à nouveau:<br/>
        <input id="passwd2" type="password" v-model="passwd2" placeholder="">
      </td></tr>
    </table>
    <button v-on:click="register" class="success" :disabled="passwd1!=passwd2 || passwd1.length<8">Créer mon compte</button>

    </div>

    <div v-if="merci">

    <h2>C'est presque prêt!</h2>

    <p><b>Un email vous attend dans votre boîte de réception.<br/> Vérifiez le dossier spam si vous ne le trouvez pas.</b><br/><br/>

    <b>Ouvrez cet email, et cliquez sur le lien qu'il contient afin d'accéder à la charte et au vote.</b> </p>

   </div>

  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Register',
  data () {
    return {
      email: '',
      passwd1: '',
      passwd2: '',
      merci: false
    }
  },
  created () {
    var user = this.$cookies.get('user')
    if (user) this.$router.push('hello')
  },
  methods: {
    register () {
      if (this.email.trim().length >= 7 && this.email.indexOf('@') >= 0 && this.passwd1 === this.passwd2 && this.passwd1.length > 7) {
        axios.post(process.env.API + '/api/register', {email: this.email, passwd: this.passwd1})
          .then(res => {
            console.log(res)
            this.merci = true
            // TODO display thank you, verify email
          })
      } else {
        console.log('XX')
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.questionForm {
  margin:auto;
}
.register input {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  color: #2c3e50;
  font-size: 2em;
  width: 300px;
}

h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
