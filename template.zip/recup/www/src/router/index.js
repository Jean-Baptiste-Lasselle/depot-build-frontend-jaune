import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
// import Register from '@/components/Register'
import Voter from '@/components/Voter'

Vue.use(Router)

export default new Router({
  mode: 'history',
  scrollBehavior (to, from, savedPosition) {
    return { x: 0, y: 0 }
  },
  routes: [
    {
      path: '/',
      name: 'Hello',
      component: Hello
    },
    {
      path: '/verif/:hash',
      name: 'Voter',
      component: Voter
    },
    /* {
      path: '/register',
      name: 'Register',
      component: Register
    }, */

    { path: '*', redirect: '/' }
  ]
})
