<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 30px;
}

button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  cursor: pointer;
}

button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  cursor:not-allowed;
}

/* The alert message box */
.alert {
  padding: 20px;
  background-color: #4CAF50; /* Green */
  color: white;
  margin-bottom: 15px;
  font-weight: bold;
  font-size:1.5em;
}

.error {background-color: #f44336;}
.success {background-color: #4CAF50;}
.info {background-color: #2196F3;}
.warning {background-color: #ff9800;}
.gris {background-color: #dddddd; color:#666;}

/* The close button */
.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

/* When moving the mouse over the close button */
.closebtn:hover {
  color: black;
}

.questionForm {
  margin:auto;
}
.questionForm input {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  color: #2c3e50;
  font-size: 1.8em;
  width: 300px;
}

@media (max-width:320px) {

  .questionForm input {
    width: 270px;
  }

}

</style>
