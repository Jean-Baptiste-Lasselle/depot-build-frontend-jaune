import Vue from 'vue'
import App from './App'
import router from './router'
import VueCookies from 'vue-cookies'

Vue.use(VueCookies)

Vue.config.productionTip = false
/**
 * fait planter webpack
 * 
 **/
// Vue.http.options.root="http://poste-devops-typique:3800/";

Vue.directive('focus-on-create', {
  bind: function (el, binding, vnode) {
    Vue.nextTick(() => {
      if (vnode.context.focusOnCreateChoice) el.focus()
    })
  }
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
})
